const NoMatch =()=>{
    return(
        <>
        <h1>404 Not found</h1>
        </>
    )
}
export default NoMatch;